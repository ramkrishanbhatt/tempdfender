import React, { useEffect, useState } from "react";
import {
  Box,
  Stack,
  TextField,
  Grid,
  IconButton,
  Typography,
  styled,
  FormControl,
  Autocomplete,
} from "@mui/material";
import { StarOutline, Upload } from "@mui/icons-material";
import {
  StyledLargeTypography,
  StyledMediumTypography,
  StyledShadowedStack,
  StyledSmallTypography,
} from "./components.Style";
import Wave from "../wave.jpg";
import { convertToTitleCase } from "./Data";

const VisuallyHiddenInput = styled("input")({
  clip: "rect(0 0 0 0)",
  clipPath: "inset(50%)",
  height: 1,
  overflow: "hidden",
  position: "absolute",
  bottom: 0,
  left: 0,
  whiteSpace: "nowrap",
  width: 1,
});

const QueueDetails = ({
  onClick,
  classes,
}: {
  onClick: any;
  classes: any[];
}) => {
  const [videos, setVideos] = useState<any>([]);
  const [selectedTag, setSelectedTag] = useState<string>("");
  const [selectedClass, setSelectedClass] = useState<string>(classes[0]);

  const getVideosByTag = async (tag: string) => {
    setSelectedTag(tag);
    const response = await fetch(
      `http://ec2-18-116-51-237.us-east-2.compute.amazonaws.com/classify-videos/?tags=${tag}`
    );
    if (response.ok) {
      const videosData = await response.json();
      setVideos(() => videosData);
    } else {
      setVideos(() => [
        {
          video_id: "66a78d5782dcf699a8aa486a",
          frames: [
            {
              time: 0.04170833333333333,
              score: 0.9999977350234984,
            },
            {
              time: 0.9592916666666668,
              score: 0.9999960660934448,
            },
            {
              time: 2.9612916666666664,
              score: 0.9250258207321168,
            },
            {
              time: 3.9622916666666663,
              score: 0.000001123611241382605,
            },
            {
              time: 6.965291666666666,
              score: 0.978612184524536,
            },
            {
              time: 7.966291666666666,
              score: 0.21982699632644653,
            },
            {
              time: 8.967291666666666,
              score: 0.9831867218017578,
            },
            {
              time: 10.969291666666663,
              score: 0.9798177480697632,
            },
            {
              time: 11.970291666666666,
              score: 0.8857378363609314,
            },
            {
              time: 12.971291666666666,
              score: 0.000002266412366225268,
            },
            {
              time: 13.972291666666663,
              score: 0.00000101952423392504,
            },
            {
              time: 14.973291666666666,
              score: 0.9999979734420776,
            },
          ],
        },
      ]);
    }
  };

  const getAverageScore = (data: any[]) => {
    let sum = 0;
    data.forEach((_) => {
      sum += _?.score;
    });
    return sum / data.length;
  };

  const getVideoDetails = async (
    video_id: string,
    times: any[],
    name: string
  ) => {
    const response = await fetch(
      `http://ec2-18-116-51-237.us-east-2.compute.amazonaws.com/get-processed-data/${video_id}`
    );
    if (response.ok) {
      const videosData = await response.json();
      onClick(video_id || "", times, videosData.fileData.file_path, name);
    }
  };

  useEffect(() => {
    getVideosByTag(classes[0]);
  }, []);

  return (
    <>
      <Grid container spacing={2} columns={{ md: 12 }}>
        <Grid item container md={5} spacing={2}>
          {data.map((_) => (
            <Grid item md={6}>
              <StyledShadowedStack spacing={0.5}>
                <StyledSmallTypography color={"gray"}>
                  {_.text}
                </StyledSmallTypography>
                <StyledMediumTypography display={"flex"}>
                  {_.value}&nbsp;
                  <span
                    style={{
                      border: "1px solid #BFD7ED",
                      borderRadius: "50px",
                      padding: "2px",
                      boxShadow: "rgba(149, 157, 165, 0.2) 0px 8px 24px",
                      fontSize: "8px",
                      height: "fit-content",
                      marginTop: 3,
                    }}
                  >
                    {_.percentage}
                  </span>
                </StyledMediumTypography>
                <img src={Wave} width={"100%"} height={"35px"} />
              </StyledShadowedStack>
            </Grid>
          ))}
        </Grid>
        <Grid item md={1.5}>
          <StyledShadowedStack
            sx={{
              flexDirection: "column",
              alignItems: "center",
              justifyContent: "center",
            }}
            height={"213px"}
            spacing={0.5}
          >
            <IconButton component="label" sx={{ alignSelf: "end", p: 0 }}>
              <Upload />
              <VisuallyHiddenInput type="file" />
            </IconButton>
            <StyledShadowedStack
              sx={{
                boxShadow: "none",
                height: "-webkit-fill-available",
                flexDirection: "row",
                alignItems: "center",
                justifyContent: "center",
              }}
            >
              <StyledLargeTypography flex={1}>
                Add New Queue
              </StyledLargeTypography>
            </StyledShadowedStack>
          </StyledShadowedStack>
        </Grid>
        <Grid item container spacing={0.5} md={5.5}>
          <Grid item md={12}>
            <StyledShadowedStack
              sx={{
                background: "#006dd9",
                color: "white",
                flexDirection: "row",
                alignItems: "center",
                justifyContent: "center",
              }}
            >
              <StyledMediumTypography alignItems={"center"}>
                Queue Statistics
              </StyledMediumTypography>
            </StyledShadowedStack>
          </Grid>
          <Grid item md={6}>
            {statics1.map((_) => (
              <StyledShadowedStack
                sx={{ flexDirection: "row" }}
                justifyContent={"space-between"}
                mb={0.5}
              >
                <StyledSmallTypography color={"gray"}>
                  {_.text}
                </StyledSmallTypography>
                <StyledSmallTypography>{_.value}</StyledSmallTypography>
              </StyledShadowedStack>
            ))}
          </Grid>
          <Grid item md={6}>
            {statics2.map((_) => (
              <StyledShadowedStack
                sx={{ flexDirection: "row" }}
                justifyContent={"space-between"}
                mb={0.5}
              >
                <StyledSmallTypography color={"gray"}>
                  {_.text}
                </StyledSmallTypography>
                <StyledSmallTypography>{_.value}</StyledSmallTypography>
              </StyledShadowedStack>
            ))}
          </Grid>
        </Grid>
        <Grid item md={12}>
          <StyledShadowedStack
            sx={{
              background: "#006dd9",
              color: "white",
              flexDirection: "row",
              alignItems: "center",
              justifyContent: "center",
            }}
            fontWeight={600}
          >
            Live Queuing Details
          </StyledShadowedStack>
        </Grid>
        <Grid item md={2.5}>
          <FormControl sx={{ mt: 0.7 }} fullWidth>
            <Autocomplete
              disablePortal
              id="combo-box-demo"
              getOptionLabel={(o) => convertToTitleCase(o)}
              options={classes}
              sx={{ width: 300 }}
              onChange={(event: any, newValue: string | null) => {
                setSelectedClass(newValue || "");
                getVideosByTag(newValue || ("" as string));
              }}
              value={selectedClass}
              renderInput={(params) => <TextField {...params} label="Class" />}
            />
          </FormControl>
        </Grid>
        <Grid item md={12} marginBottom={1}>
          <Stack
            color={"gray"}
            fontSize={"12px"}
            fontWeight={600}
            direction={"row"}
          >
            <StyledSmallTypography
              ml={1.5}
              display={"flex"}
              alignItems={"flex-start"}
              flex={1}
            >
              Item Details
            </StyledSmallTypography>
            <StyledSmallTypography width={150}>Pin Queue</StyledSmallTypography>
            <StyledSmallTypography width={150}>Duration</StyledSmallTypography>
            <StyledSmallTypography width={140}>
              Frames Count
            </StyledSmallTypography>
            <StyledSmallTypography width={170}>Score</StyledSmallTypography>
          </Stack>
        </Grid>
      </Grid>
      <Box flex={1} height={"inherit"} overflow={"hidden"}>
        <Grid
          container
          spacing={1}
          columns={{ md: 12 }}
          height={"inherit"}
          overflow={"hidden"}
        >
          <Grid
            height={"inherit"}
            maxHeight={"45vh"}
            overflow={"auto"}
            pl={1}
            item
            md={12}
          >
            {videos.length ? (
              videos.map((_: any) => (
                <StyledShadowedStack
                  mb={1}
                  sx={{
                    boxShadow: "rgba(0, 0, 0, 0.16) 0px 1px 4px",
                    flexDirection: "row",
                    ":hover": {
                      cursor: "pointer",
                      bgcolor: "#006dd9",
                      color: "white",
                    },
                  }}
                  maxWidth={"-webkit-fill-available"}
                  onClick={() => {
                    const times = _?.frames?.map((_: any) => _?.time);
                    getVideoDetails(_?.video_id, times, _?.file_data?.filename);
                  }}
                >
                  <StyledSmallTypography
                    maxWidth={"-webkit-fill-available"}
                    textOverflow={"ellipsis"}
                    whiteSpace={"nowrap"}
                    overflow={"hidden"}
                    flex={1}
                    display={"flex"}
                  >
                    {_?.file_data?.filename}
                  </StyledSmallTypography>
                  <Typography fontSize={"6px"} width={150}>
                    <StarOutline fontSize="small" />
                  </Typography>
                  <Typography width={150}>00:25</Typography>
                  <Typography width={150}>{_?.frames?.length}</Typography>
                  <Typography width={150}>
                    {parseFloat(getAverageScore(_?.frames).toFixed(4))}
                  </Typography>
                </StyledShadowedStack>
              ))
            ) : (
              <StyledShadowedStack
                mb={1}
                sx={{
                  boxShadow: "rgba(0, 0, 0, 0.16) 0px 1px 4px",
                  flexDirection: "column",
                  alignItems: "center",
                }}
                maxWidth={"-webkit-fill-available"}
              >
                <StyledMediumTypography>No data found.</StyledMediumTypography>
              </StyledShadowedStack>
            )}
          </Grid>
        </Grid>
      </Box>
    </>
  );
};

export default QueueDetails;

const data = [
  {
    text: "Total Volume",
    value: "265,903",
    percentage: "100.00%",
  },
  {
    text: "AI Moderated Volume",
    value: "239,313",
    percentage: "92.00%",
  },
  {
    text: "Queued Volume",
    value: "2,955",
    percentage: "1.00%",
  },
  {
    text: "Transferred Volume",
    value: "26,590",
    percentage: "8.00%",
  },
];

const statics1 = [
  {
    text: "Average AHT",
    value: "0:00:26",
  },
  {
    text: "Closed on Time",
    value: "99.14%",
  },
  {
    text: "Total Review Time",
    value: "192:02:20",
  },
  {
    text: "Total Live Moderators",
    value: "48",
  },
];

const statics2 = [
  {
    text: "Total Breached Items",
    value: "0",
  },
  {
    text: "# Queues Breached",
    value: "0",
  },
  {
    text: "Average Queue Aging",
    value: "0:18:10",
  },
  {
    text: "Total Daily Throughput",
    value: "53,180",
  },
];
